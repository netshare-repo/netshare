import NodeDevice from "../models/NodeDevice.js";

/**
 * Normalizes and calculates a composite suitability score for a node.
 * 
 * Formula:
 * Score = (0.40 * Reliability) + (0.25 * LatencyScore) + (0.20 * BandwidthAvailability) + (0.15 * RegionMatch)
 * 
 * Latency is inverted: LatencyScore = 1 - normalizedLatency (lower latency yields higher score).
 */
export const calculateNodeScore = (node, targetRegion) => {
  // 1. Reliability Score (0.0 to 1.0)
  const rawReliability = typeof node.reliabilityScore === "number" ? node.reliabilityScore : 100;
  const reliabilityScore = Math.max(0, Math.min(1, rawReliability / 100));

  // 2. Latency Score (Lower latency is better, normalized over 500ms max baseline)
  const rawLatency = typeof node.latencyMs === "number" && node.latencyMs > 0 ? node.latencyMs : 50;
  const normalizedLatency = Math.min(1, Math.max(0, rawLatency / 500));
  const latencyScore = 1 - normalizedLatency;

  // 3. Bandwidth Availability Score (Remaining ratio 0.0 to 1.0)
  const limitMB = node.bandwidthLimitMB || 2048;
  const usedMB = node.usedBandwidthMB || 0;
  const availableMB = Math.max(0, limitMB - usedMB);
  const bandwidthAvailability = limitMB > 0 ? Math.min(1, availableMB / limitMB) : 0;

  // 4. Region Match Score (Exact match = 1.0, Global/any = 0.5, mismatch = 0.1)
  let regionMatch = 0.1;
  if (targetRegion && node.region) {
    const nodeReg = node.region.trim().toLowerCase();
    const targetReg = targetRegion.trim().toLowerCase();
    if (nodeReg === targetReg) {
      regionMatch = 1.0;
    } else if (nodeReg === "global" || targetReg === "global") {
      regionMatch = 0.7;
    }
  } else {
    regionMatch = 0.5;
  }

  // Composite Weighted Score
  const compositeScore =
    0.40 * reliabilityScore +
    0.25 * latencyScore +
    0.20 * bandwidthAvailability +
    0.15 * regionMatch;

  return {
    nodeId: node._id,
    node,
    score: parseFloat(compositeScore.toFixed(4)),
    metrics: {
      reliabilityScore,
      latencyScore,
      bandwidthAvailability,
      regionMatch,
    },
  };
};

/**
 * Finds the optimal node device for a task matching region and capacity constraints.
 * Falls back to available active nodes if exact regional match has no capacity.
 */
export const findAvailableNode = async (targetRegion) => {
  // Query only active nodes with capacity and remaining bandwidth
  const candidateNodes = await NodeDevice.find({
    status: "active",
    $expr: {
      $lt: ["$currentActiveTasks", "$maxConcurrentTasks"],
    },
  });

  if (!candidateNodes || candidateNodes.length === 0) {
    return null;
  }

  // Filter out nodes that have completely exhausted their bandwidth
  const eligibleNodes = candidateNodes.filter((node) => {
    const limit = node.bandwidthLimitMB || 2048;
    const used = node.usedBandwidthMB || 0;
    return used < limit;
  });

  if (eligibleNodes.length === 0) {
    return null;
  }

  // Score all eligible candidates
  const scoredNodes = eligibleNodes.map((node) =>
    calculateNodeScore(node, targetRegion)
  );

  // Sort descending by score
  scoredNodes.sort((a, b) => b.score - a.score);

  return scoredNodes[0].node;
};

/**
 * Scores and ranks an array of candidate nodes for ML preparation and observability.
 */
export const rankAllNodes = (nodes, targetRegion) => {
  return nodes
    .map((node) => calculateNodeScore(node, targetRegion))
    .sort((a, b) => b.score - a.score);
};