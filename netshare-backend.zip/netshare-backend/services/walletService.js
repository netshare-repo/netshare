import Wallet from "../models/Wallet.js";
import CreditTransaction from "../models/CreditTransaction.js";

export const deductCredits = async ({ userId, taskId = null, amount, description }) => {
  if (amount <= 0) {
    throw new Error("Amount must be greater than zero");
  }

  const wallet = await Wallet.findOne({ userId });

  if (!wallet) {
    throw new Error("Wallet not found");
  }

  if (wallet.balance < amount) {
    throw new Error("Insufficient wallet balance");
  }

  wallet.balance -= amount;
  wallet.spentCredits += amount;
  await wallet.save();

  await CreditTransaction.create({
    userId,
    taskId,
    type: "debit",
    amount,
    description,
  });

  return wallet;
};

export const addCredits = async ({ userId, taskId = null, amount, description }) => {
  if (amount <= 0) {
    throw new Error("Amount must be greater than zero");
  }

  const wallet = await Wallet.findOne({ userId });

  if (!wallet) {
    throw new Error("Wallet not found");
  }

  wallet.balance += amount;
  wallet.earnedCredits += amount;
  await wallet.save();

  await CreditTransaction.create({
    userId,
    taskId,
    type: "credit",
    amount,
    description,
  });

  return wallet;
};