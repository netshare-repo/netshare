import mongoose from "mongoose";

const nodeDeviceSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    deviceName: {
      type: String,
      required: true,
      trim: true,
    },

    deviceId: {
      type: String,
      default: "",
    },

    deviceFingerprint: {
      type: String,
      default: "",
    },

    region: {
      type: String,
      required: true,
      trim: true,
    },

    status: {
      type: String,
      enum: ["active", "inactive", "paused", "busy"],
      default: "inactive",
    },

    bandwidthLimitMB: {
      type: Number,
      required: true,
      default: 2048,
    },

    usedBandwidthMB: {
      type: Number,
      default: 0,
    },

    uploadSpeedCapMbps: {
      type: Number,
      default: 5,
    },

    downloadSpeedCapMbps: {
      type: Number,
      default: 10,
    },

    speedCapMbps: {
      type: Number,
      default: 10,
    },

    maxConcurrentTasks: {
      type: Number,
      default: 1,
    },

    currentActiveTasks: {
      type: Number,
      default: 0,
    },

    reliabilityScore: {
      type: Number,
      default: 100,
      min: 0,
      max: 100,
    },

    successRate: {
      type: Number,
      default: 100,
      min: 0,
      max: 100,
    },

    latencyMs: {
      type: Number,
      default: 45,
    },

    lastSeenAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

export default mongoose.model("NodeDevice", nodeDeviceSchema);