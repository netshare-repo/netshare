import express from "express";
import {
  registerNode,
  getNodeDashboard,
  getMyNode,
  updateNodeSettings,
  startParticipation,
  stopParticipation,
  getCurrentSession,
  getNodeTransactions,
  getAssignedTask,
} from "../controllers/nodeController.js";
import { protect } from "../middleware/authMiddleware.js";
import { allowRoles } from "../middleware/roleMiddleware.js";

const router = express.Router();

const allowedNodeRoles = ["node_participant", "both", "admin"];

// Node Dashboard
router.get(
  "/dashboard",
  protect,
  allowRoles(...allowedNodeRoles),
  getNodeDashboard
);

// Registration & Profile
router.post(
  "/register",
  protect,
  allowRoles(...allowedNodeRoles),
  registerNode
);

router.get(
  "/my-node",
  protect,
  allowRoles(...allowedNodeRoles),
  getMyNode
);

// Settings
router.put(
  "/settings",
  protect,
  allowRoles(...allowedNodeRoles),
  updateNodeSettings
);

// Session Control (Supports both POST and PUT for compatibility)
router.post(
  "/start",
  protect,
  allowRoles(...allowedNodeRoles),
  startParticipation
);

router.put(
  "/start",
  protect,
  allowRoles(...allowedNodeRoles),
  startParticipation
);

router.post(
  "/stop",
  protect,
  allowRoles(...allowedNodeRoles),
  stopParticipation
);

router.put(
  "/stop",
  protect,
  allowRoles(...allowedNodeRoles),
  stopParticipation
);

// Live Session Monitoring
router.get(
  "/session/current",
  protect,
  allowRoles(...allowedNodeRoles),
  getCurrentSession
);

// Earnings & Transactions
router.get(
  "/transactions",
  protect,
  allowRoles(...allowedNodeRoles),
  getNodeTransactions
);

// Assigned Tasks
router.get(
  "/assigned-task",
  protect,
  allowRoles(...allowedNodeRoles),
  getAssignedTask
);

export default router;